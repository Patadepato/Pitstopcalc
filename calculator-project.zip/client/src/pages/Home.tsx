import Calculator from "@/components/Calculator";

export default function Home() {
  return (
    <div className="min-h-screen bg-[#0b0f16] font-[Inter] text-[#e0e0e0] p-4 md:p-6 animate-[fadeIn_0.6s_ease-in]">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-[#58a6ff] mb-2 tracking-wide">
            Calculadora Pitstop
          </h1>
          <p className="text-sm md:text-base opacity-80">
            Calcula el costo de modificaciones y reparaciones para tu vehículo
          </p>
        </header>
        
        <Calculator />
        
        <footer className="text-center text-sm text-gray-500 mt-8 mb-8">
          © {new Date().getFullYear()} Calculadora Pitstop | Todos los derechos reservados
        </footer>
      </div>
    </div>
  );
}
