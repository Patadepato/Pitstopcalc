import { formatCurrency } from "@/lib/utils";

interface Item {
  id: string;
  name: string;
  price: number;
  usePercentage?: boolean;
}

interface CalculatorRowProps {
  item: Item;
  section: string;
  quantity: number;
  price: number;
  onQuantityChange: (quantity: number) => void;
}

export default function CalculatorRow({
  item,
  section,
  quantity,
  price,
  onQuantityChange,
}: CalculatorRowProps) {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newQuantity = parseInt(e.target.value) || 0;
    if (newQuantity >= 0) {
      onQuantityChange(newQuantity);
    }
  };

  return (
    <tr className="border-b border-gray-700/30 hover:bg-[#0d1117]/30">
      <td className="py-3 px-2">{item.name}</td>
      <td className="py-2 px-2">
        <input 
          type="number" 
          className="bg-[#0d1117]/70 w-full rounded-lg border border-gray-700 px-3 py-1.5 transition-all focus:border-[#58a6ff] focus:ring-1 focus:ring-[#58a6ff]/30 focus:outline-none text-[#f0f6fc]" 
          min="0"
          value={quantity || ''}
          onChange={handleInputChange}
          data-section={section}
          data-item={item.id}
        />
      </td>
      <td className="py-3 px-2 font-medium text-[#79c0ff]" data-price={`${section}-${item.id}`}>
        {formatCurrency(price)}
      </td>
    </tr>
  );
}
