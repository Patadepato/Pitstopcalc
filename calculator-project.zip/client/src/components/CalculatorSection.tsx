import CalculatorRow from "./CalculatorRow";

interface ItemState {
  quantity: number;
  price: number;
}

interface Item {
  id: string;
  name: string;
  price: number;
  usePercentage?: boolean;
}

interface CalculatorSectionProps {
  title: string;
  icon: string;
  items: Item[];
  section: string;
  state: { [key: string]: ItemState };
  onQuantityChange: (itemId: string, quantity: number, basePrice: number, usePercentage?: boolean) => void;
  animationDelay: string;
  compact?: boolean;
  showToggle?: boolean;
  toggleLabel?: string;
  onToggle?: () => void;
}

export default function CalculatorSection({
  title,
  icon,
  items,
  section,
  state,
  onQuantityChange,
  animationDelay,
  compact = false,
  showToggle = false,
  toggleLabel = "Mostrar más",
  onToggle
}: CalculatorSectionProps) {
  return (
    <div 
      className="bg-[rgba(36,41,46,0.6)] backdrop-blur-xl rounded-[20px] shadow-lg p-5 mb-6 transition-all duration-300 hover:shadow-xl hover:shadow-[#1f6feb]/10 animate-[fadeIn_0.6s_ease-in]" 
      style={{ animationDelay }}
    >
      <h2 className="text-xl font-semibold text-[#58a6ff] mb-4 flex items-center">
        <span className="mr-2">{icon}</span> {title}
      </h2>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-700/50">
              <th className="text-left py-3 px-2 w-1/2 font-semibold">Elemento</th>
              <th className="text-left py-3 px-2 w-1/4 font-semibold">Cantidad</th>
              <th className="text-left py-3 px-2 w-1/4 font-semibold">Precio</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <CalculatorRow
                key={item.id}
                item={item}
                section={section}
                quantity={state[item.id]?.quantity || 0}
                price={state[item.id]?.price || 0}
                onQuantityChange={(quantity) => 
                  onQuantityChange(item.id, quantity, item.price, item.usePercentage)}
              />
            ))}
          </tbody>
        </table>
      </div>
      
      {showToggle && onToggle && (
        <div className="mt-4 text-right">
          <button 
            className="text-sm text-[#58a6ff] hover:text-[#79c0ff] underline"
            onClick={onToggle}
          >
            {toggleLabel}
          </button>
        </div>
      )}
    </div>
  );
}
